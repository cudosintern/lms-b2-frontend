/**
 * API Endpoint Configuration for IonCUDOS Module
 * Central location for all CUDOS-related API endpoints
 */

export const ApiEndpoint = {
  // Common master delete endpoint (shared across modules)
  master_soft_delete: "comman_function/soft_delete",

  // Bloom's Domain specific endpoints
  bloomDomain: {
    save_bloom_domain: "bloom_domain/save_bloom_domain", // Create/Update Bloom's Domain
    bloom_domain_list: "bloom_domain/bloom_domain_list", // Fetch all Bloom's Domains
  },

  // Bloom's Level specific endpoints (for future implementation)
  bloomLevel: {
    save_bloom_level: "bloom_level/save_bloom_level",
    bloom_level_list: "comman_function/bloom_level_list",
  },

  // Program Outcome specific endpoints
  program: {
    outcome_list: "comman_function/program_outcome_list",
  },

  // Additional CUDOS endpoints can be added here
  // Example:
  // programOutcome: {
  //   save_program_outcome: "program_outcome/save_program_outcome",
  // },

  configType: {
    list: "api/v1/config-type/list",
    save: "api/v1/config-type/save",
    delete: "api/v1/config-type/delete",
  },
  crossDeptMentor: {
    departments: "api/v1/cross-dept-mentor/departments",
    users: "api/v1/cross-dept-mentor/users",
    curriculums: "api/v1/cross-dept-mentor/curriculums",
    mentorsFromOtherDept: "api/v1/cross-dept-mentor/mentors-from-other-dept",
    mentorsToOtherDept: "api/v1/cross-dept-mentor/mentors-to-other-dept",
    save: "api/v1/cross-dept-mentor/save",
    update: "api/v1/cross-dept-mentor/update",
    delete: "api/v1/cross-dept-mentor/delete",
  },
  mentorList: {
    departments: "api/v1/mentoring/mentor-list/departments",
    programs: "api/v1/mentoring/mentor-list/programs",
    curriculums: "api/v1/mentoring/mentor-list/curriculums",
    semesters: "api/v1/mentoring/mentor-list/semesters",
    students: "api/v1/mentoring/mentor-list/students",
    mentorsMentees: "api/v1/mentoring/mentor-list/mentors-mentees",
    exportPdf: "api/v1/mentoring/mentor-list/export-pdf",
  },
  mentoringSession: {
    curriculumList: "mentoring-session/get_academic_batch_list",
    semestersByCurriculum: "mentoring-session/get_semesters_by_academic_batch",
    groupsByCurriculum: "mentoring-session/get_groups_by_academic_batch",
    groupMentees: "mentoring-session/get_group_mentees",
    saveMentoringSession: "mentoring-session/save_mentoring_session",
    getMentoringSessions: "mentoring-session/get_mentoring_sessions",
    getSessionMentees: "mentoring-session/get_session_mentees",
    updateMentoringSession: "mentoring-session/update_mentoring_session",
    deleteMentoringSession: "mentoring-session/delete_mentoring_session",
    updateSessionStatus: "mentoring-session/update_session_status",
  },
  mentoring: {
    questionnaire: "api/v1/mentoring/questionnaires",
    sessions: "api/v1/mentoring/sessions",
    upload: "api/v1/mentoring/upload",
  },
  studentCourseRegistration: {
    checkRegistrationStatus:
      "student-course-registration/check_registration_status",
    registrationAcademicBatchList:
      "student-course-registration/get_registration_academic_batch_list",
    registrationSemesterList:
      "student-course-registration/get_registration_semester_list",
    validateRegistrationDueDate:
      "student-course-registration/validate_registration_due_date",
    availableCourses:
      "student-course-registration/available-courses",
    registrationSectionList:
      "student-course-registration/get_registration_section_list",
    registeredCourses:
      "student-course-registration/registered-courses",
  },
  material: {
    createMaterial: "/api/v1/material/create_material",
    materialList: "/api/v1/material/material_list",
    studentList: "/api/v1/material/student_list",
    shareMaterial: "/api/v1/material/share_material",
    downloadMaterial: "/api/v1/material/download_material",
    updateMaterial: "/api/v1/material/update_material",
    materialMappingList: "/api/v1/material/material_mapping_list",
  },

  timetable: {
    scheduledClasses: "/api/v1/timetable/scheduled-classes",
    scheduledClass: (id: number) => `/api/v1/timetable/scheduled-classes/${id}`,
    deleteTimetable: (id: number) => `/api/v1/timetable/${id}`,
    resetDates: (id: number) => `/api/v1/timetable/${id}/reset-dates`,
    copyDay: "/api/v1/timetable/copy-day",
    syncRange: (id: number) => `/api/v1/timetable/${id}/sync-range`,
    exportPdf: "/api/v1/comman_function/timetable/export-pdf",
    getTimetables: "/api/v1/timetable/timetables",
  },
  

  topic: {
    curriculumList: "api/v1/topic_management/curriculum_list",
    semesterList: "api/v1/topic_management/semester_list",
    courseList: "api/v1/topic_management/course_list",
    sectionList: "api/v1/topic_management/section_list_post",
    topicList: "api/v1/topic_management/topic_list",
    topicsToImport: "api/v1/topic_management/topics-to-import",
    importTopics: "api/v1/topic_management/import-topics",
    importTopic: "api/v1/topic_management/import_topic",
    importAllTopics: "api/v1/topic_management/import_all_topics",
    bulkImportTopics: "api/v1/topic_management/bulk_import_topics",
    updateTopic: "api/v1/topic_management/update_topic",
    deleteTopic: "api/v1/topic_management/delete_topic",
    instructorList: "api/v1/topic_management/instructor_list",
    updateInstructor: "api/v1/topic_management/update_instructor",
    cudosTopics: "api/v1/topic_management/cudos_topics",
    importCudosTopics: "api/v1/topic_management/import_cudos_topics",
    topicSchedules: "api/v1/topic_management/topic_schedules",
    updateSchedule: "api/v1/topic_management/update_schedule",
    addSchedule: "api/v1/topic_management/add_schedule",
    addExtraClass: "api/v1/topic_management/add_extra_class",
    updateMapping: "api/v1/topic_management/update_mapping",
    addNewTopic: "api/v1/topic_management/add_new_topic"
  },

  quiz: {
    // Meta dropdowns (GET)
    curriculumList: "/api/v1/manage-quiz/meta/curriculums",
    semesterList: "/api/v1/manage-quiz/meta/terms",
    courseList: "/api/v1/manage-quiz/meta/courses",
    sectionList: "/api/v1/manage-quiz/meta/sections",
    topics: "/api/v1/manage-quiz/meta/topics",

    // CRUD (faculty)
    list: "/api/v1/manage-quiz/list",
    create: "/api/v1/manage-quiz/create",
    delete: (id: number) => `/api/v1/manage-quiz/${id}`,
    details: (id: number) => `/api/v1/manage-quiz/${id}`,

    // Detail pages (faculty)
    students: (id: number) => `/api/v1/manage-quiz/${id}/students`,
    share: (id: number) => `/api/v1/manage-quiz/${id}/share`,
    start: (id: number) => `/api/v1/manage-quiz/${id}/start`,
    submitAnswers: (id: number) => `/api/v1/manage-quiz/${id}/submit-answer`,
    downloadFile: (id: number) => `/api/v1/manage-quiz/${id}/download-file`,
    assignStudents: "/api/v1/manage_quiz/assign_students",
    deleteQuiz: "/api/v1/manage_quiz/delete_quiz/:id",
    getQuizQuestions: "/api/v1/manage_quiz/questions",
    getAssignedStudents: (quizId: number) => `/api/v1/manage_quiz/${quizId}/assigned-students`
  },

  studentAssignmentReport: {
    assignmentList: "api/v1/student_assignment/assignment_list",
    report: "api/v1/student_assignment/report",
    export: "api/v1/student_assignment/export",
  },

  // ── Consolidated Absentees Report ──────────────────────────────────────────
  consolidatedAbsenteesReport: {
    departments: "api/v1/conso_absentees_report/departments",
    programs: (id: number) => `api/v1/conso_absentees_report/programs/${id}`,
    curriculum: (id: number) => `api/v1/conso_absentees_report/curriculum/${id}`,
    terms: (id: number) => `api/v1/conso_absentees_report/terms/${id}`,
    sections: (id: number) => `api/v1/conso_absentees_report/sections/${id}`,
    dateInfo: "api/v1/conso_absentees_report/date-info",
    report: "api/v1/conso_absentees_report/report",
    drilldown: "api/v1/conso_absentees_report/drilldown",
    exportPdf: "api/v1/conso_absentees_report/export/pdf",
    exportXls: "api/v1/conso_absentees_report/export/xls",
  },

  topicCoverage: {
    curriculum:   "api/v1/topic_coverage/curriculum",
    terms:        (curriculumId: number) => `api/v1/topic_coverage/terms/${curriculumId}`,
    courses:      "api/v1/topic_coverage/courses",
    courseTopics: "api/v1/topic_coverage/course-topics",
    exportPdf:    "api/v1/topic_coverage/export-pdf",
  },

  myClass: {
    dropdowns: "api/v1/my-class/dropdowns",
    classList: "api/v1/my-class/class-list",
  },

  consolidatedStudentMarksReport: {
    departments: "api/v1/conso_student_marks_report/departments",
    curriculums: "api/v1/conso_student_marks_report/curriculums",
    terms: "api/v1/conso_student_marks_report/terms",
    sections: "api/v1/conso_student_marks_report/sections",
    courses: "api/v1/conso_student_marks_report/courses",
    report: "api/v1/conso_student_marks_report/report",
    graph: "api/v1/conso_student_marks_report/graph",
    export: "api/v1/conso_student_marks_report/export",
  },

  studentAttendanceReport: {
    curriculums: "api/v1/student_attendance_report/curriculums",
    terms: (curriculumId: string) => `api/v1/student_attendance_report/terms/${curriculumId}`,
    courses: "api/v1/student_attendance_report/courses",
    sections: (curriculumId: string, termId: string) =>`api/v1/student_attendance_report/sections/${curriculumId}/${termId}`,
    lessonDates: "api/v1/student_attendance_report/lesson-dates",
    summary: "api/v1/student_attendance_report/summary",
  },

  studentQuiz: {
    myQuizzes: "/api/v1/student-quiz/my-quizzes",
    start: (quiz_id: number) =>`/api/v1/student-quiz/${quiz_id}/start`,
    submit: (quiz_id: number) =>`/api/v1/student-quiz/${quiz_id}/submit`,
    downloadFile: (quiz_id: number) =>`/api/v1/student-quiz/${quiz_id}/download`,
  },
} as const;

// Alias for backward compatibility
export const LmsApiEndpoint = ApiEndpoint;
