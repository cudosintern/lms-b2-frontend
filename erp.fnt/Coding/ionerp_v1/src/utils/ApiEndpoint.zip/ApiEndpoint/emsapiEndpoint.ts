export const ApiEndpoint = {
  login: "auth/staff_login",
  change_password: "auth/change-password",
  FORGOT_PASSWORD: "auth/forgot-password",
  master_soft_delete: "comman_function/soft_delete",

  dashboard_info: "dashboard_info_route/dashboard_info",
  dashboard_info_all_data: "dashboard_info_route/dashboard_info_all_data",

  fetch_result_year_options: "comman_function/fetch_result_year_options",

  department: {
    save_department: "department/save_department",
    department_list: "comman_function/department_list",
  },

  questionnaire: {
    questionnaire_list: "lms_mmp_questionnaire/get_questionnaire_list",
    questionnaire_full: "lms_mmp_questionnaire/get_questionnaire_full",
    save_questionnaire: "lms_mmp_questionnaire/save_questionnaire",
    delete_questionnaire: "lms_mmp_questionnaire/delete_questionnaire",
    delete_question: "lms_mmp_questionnaire/delete_question",
    delete_option: "lms_mmp_questionnaire/delete_option",
    field_setting_list:
      "lms_questionnaire_field_setting/get_questionnaire_field_setting",
  },

  question_type: {
    get_question_type_list: "lms_question_type/get_question_type_list",
    get_questionnaire_type_list: "lms_questionnaire_type/get_questionnaire_type_list",
  },

  mentorMentee: {
    group_list: "lms_mentor_group/get_mentors_group_list",
    academic_batch_list: "lms_mentors_group/get_academic_batch_list",
    semesters_by_academic_batch:
      "lms_mentors_group/get_semesters_by_academic_batch",
    groups_by_academic_batch:
      "lms_mentors_group/get_groups_by_academic_batch",
    save_group: "lms_mentors_group/save_mentors_group",
    group_complete: "lms_mentors_group/get_group_complete",
    dropdowns: "lms_mmp/common_dropdowns",
    terms: "lms_mentor_group_term/get_mentors_group_terms",
    save_mentors: "lms_mentors_group/map_mentors",
    mentors: "lms_mentors_group/get_group_mentors",
    save_mentees: "lms_mentors_group/map_mentees",
    mentees: "lms_mentors_group/get_group_mentees",
    delete_mentee: "lms_mentors_group/delete_mentee",
  },

  mentoringSession: {
    group_mentees: "lms_mentoring_session/get_group_mentees",
  },

  bos: {
    list: "bos_members/list",
    save: "bos_members/save",
    delete: "bos_members/delete",
  },

  common_api: {
    deportment_list: "comman_function/get_dept_programtype",
    batch_cycle_list: "comman_function/batch_cycle_list",
    get_semester_list: "comman_function/get_semester_list",
    occubationoption: "course_type/get_temp_cia_occasion",
    get_batch_terms: "class_time_table/get_batch_terms",
    gettimetablesession: "class_time_table/fetch_student_section_list",
    get_section_list: "comman_function/fetch_student_section_list",
    get_cycle_semester_list: "comman_function/get_cycle_semester_list",
    fetch_student_section_list: "comman_function/fetch_student_section_list",
    fetch_student_course: "course_reg/fetch_student_course_usn",
    get_student_course_usn: "std_exam_reg/fetch_student_course",
    get_university_list: "",
    is_result_yearbacklog: "comman_function/is_result_yearbacklog",
    is_backlog_with_cia_see: "comman_function/is_backlog_with_cia_see",
    is_cycle: "comman_function/is_cycle",
    grade_cardno_sem: "comman_function/get_gc_sem",
    fetch_backlog_course: "comman_function/fetch_backlog_course",
    school_department_list: "/comman_function/school_department_list",
    fetch_gc_sem: "comman_function/get_gc_sem",
    upload_gc_csv: "grade_card_no/upload_gc_csv",
    fetch_gc: "grade_card_no/fetch_gc",
  }, allMaster: {
    get_all_masters_list: "all_master/all_masters_list",
    get_all_org_info: "",
    parents_occupation_master_list: "all_master/parents_occupation_master_list",
    save_parents_occupation_master: "all_master/save_parents_occupation_master",
    event_type_master_list: "all_master/event_type_master_list",
    save_event_type_master: "all_master/save_event_type_master",
    course_type_list: "all_master/course_type_list",
    save_course_type: "all_master/save_course_type",
    occasion_type_list: "all_master/occasion_type_list",
    save_occasion_type: "all_master/save_occasion_type",
    exam_session_list: "all_master/exam_session_list",
    save_exam_session: "all_master/save_exam_session",
    caste_list: "all_master/caste_list",
    save_caste: "all_master/save_caste",
    city_list: "comman_function/city_list",
    exam_hall_list: "all_master/exam_hall_list",
    save_hall: "all_master/save_hall",
    state_list: "comman_function/state_list",
    country_list: "comman_function/country_list",
    common_city_list: "comman_function/city_list",
    save_city: "all_master/save_city",
    course_occasion_type_list: "all_master/course_occasion_type_list",
  },
  academicBatch: {
    grade_type_details: "academic_batch/grade_type_details",
    getTabledata: "comman_function/academic_batch_list",
    saveAcadamicBatch: "academic_batch/save_academic_batch",
  },
} as const;
